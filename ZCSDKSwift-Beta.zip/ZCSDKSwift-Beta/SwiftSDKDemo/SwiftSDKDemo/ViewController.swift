//
//  ViewController.swift
//  SwiftSDKDemo
//
//  Created by zhangxy on 2018/12/21.
//  Copyright © 2018年 zhang. All rights reserved.
//

import UIKit

import SwiftSobotKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        ZCLibClient.getZCLibClient()?.initSobotSDK("a9905321f85448968bf519d7c894ed3e")
        
        
        UserDefaults.standard.set(true, forKey: ZCKey_ISDEBUG)
        
        
        let btn:UIButton = UIButton.init(type: UIButton.ButtonType.custom)
        
        btn.frame = CGRect(x: 100, y: 100, width: 200, height: 54)
        
        btn.setTitle("测试", for: UIControl.State.normal)
        btn.setTitleColor(UIColor.blue, for: UIControl.State.normal)
        
        self.view.addSubview(btn)
        
        btn.addTarget(self, action: #selector(startSobot), for: UIControl.Event.touchUpInside)
        
    }
    
    
    @objc func startSobot(){
        let libInitInfo  = ZCLibInitInfo.init()
        //        libInitInfo.appKey = "3c3519a237c04660bd643c1e6b46caec"
        libInitInfo.appKey = "61f0943a972d4de4a93aa70c574869de"
        libInitInfo.apiHost = "https://test.sobot.com"
        libInitInfo.userId = "123456"
        ZCLibClient.getZCLibClient()?.libInitInfo = libInitInfo
        
        ZCLibClient.getZCLibClient()?.isDebugMode = false
        
        
        let kit:ZCKitInfo = ZCKitInfo.init()
        kit.customBannerColor = UIColor.brown
        let chat = ZCChatController()
        chat.kitInfo = kit
        self.present(chat, animated: true) {
            
        }
//        self.navigationController?.pushViewController(chat, animated: true)
    }
}

